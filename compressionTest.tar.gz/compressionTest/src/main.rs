use std::fs::File;
use std::io::prelude::*;
use tar::Builder;
use flate2::write::{GzEncoder};
use flate2::Compression;

use std::{result,io};


fn main() -> result::Result<(), io::Error> {
    // {
    // let mut file = File::open("dump.crack").unwrap();
    //
    // let mut raw_data: Vec<u8> = Vec::new();
    // file.read_to_end(&mut raw_data).unwrap();
    // println!("Raw Size: {}", raw_data.len());
    //
    // let mut compressed_data = compress::compress(&raw_data);
    // println!("Compressed Size: {}", compressed_data.len());
    // println!("Diff: {}", raw_data.len() - compressed_data.len());
    //
    // let mut output = File::create("output.lz4").unwrap();
    // output.write_all(&compressed_data).unwrap();
    //
    // }
    //
    // let mut output = File::open("output.lz4").unwrap();
    // let mut compressed_data: Vec<u8> = Vec::new();
    // output.read_to_end(&mut compressed_data).unwrap();
    //
    // let mut decompressed = decompress::decompress(&compressed_data).unwrap();
    //
    // let mut new_copy = File::create("dump_copy.crack").unwrap();
    // new_copy.write_all(&decompressed).unwrap();
    {
      // let arc_template: Vec<u8> = Vec::new();
      let mut archive = Builder::new(Vec::new());
      archive.append_dir_all("","test_folder")?;
      let arc_data = archive.into_inner()?;
      println!("{}", arc_data.len());

      println!("Starting compression");
      let new_tar_file = File::create("test.tar.gz")?;
      let mut encoder = GzEncoder::new(new_tar_file, Compression::fast());
      encoder.write_all(&arc_data)?;
      encoder.finish()?;

      // let compressed_data = compress::compress(&arc_data);

      // let mut enc_arr: Vec<u8> = vec![0; arc_data.len()];
      // let mut encoder = gzip::Encoder::new(enc_arr).unwrap();
      // encoder.write_all(&arc_data).unwrap();
      // let compressed_data = encoder.finish().into_result().unwrap();
      // println!("Compression finished");

      
      // new_tar_file.write_all(&compressed_data).unwrap();
    }

    // let mut output = File::open("test.tar.lz4").unwrap();
    // let mut compressed_data: Vec<u8> = Vec::new();
    // output.read_to_end(&mut compressed_data).unwrap();
    
    // let mut decompressed = decompress::decompress(&compressed_data).unwrap();
    
    // let mut new_copy = File::create("test_folder.tar").unwrap();
    // new_copy.write_all(&decompressed).unwrap();
    Ok(())
}
